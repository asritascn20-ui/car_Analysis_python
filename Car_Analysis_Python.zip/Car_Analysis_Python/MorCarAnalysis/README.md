# MorCarAnalysis

# Car Analysis Insights

1. Midsize cars type in majority
2. Most of the cars belogs to US Origin
3. There is a positive correlation between Price and Horsepower
